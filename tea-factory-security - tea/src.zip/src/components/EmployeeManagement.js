import React, { useState } from 'react';
import {
  Box,
  Card,
  CardContent,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  Button,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Fab,
  Grid,
  Avatar
} from '@mui/material';
import { Add, Person, Search } from '@mui/icons-material';
import { motion } from 'framer-motion';

const EmployeeManagement = () => {
  const [employees, setEmployees] = useState([
    { 
      id: 1, 
      name: 'Kasun Silva', 
      department: 'Production', 
      status: 'Present', 
      checkIn: '08:30',
      role: 'Supervisor',
      contact: '077-1234567'
    },
    { 
      id: 2, 
      name: 'Nimal Perera', 
      department: 'Quality Control', 
      status: 'Present', 
      checkIn: '08:15',
      role: 'QC Inspector',
      contact: '077-2345678'
    },
    { 
      id: 3, 
      name: 'Sunil Fernando', 
      department: 'Packaging', 
      status: 'Absent', 
      checkIn: '-',
      role: 'Operator',
      contact: '077-3456789'
    },
    { 
      id: 4, 
      name: 'Chamila Rathnayake', 
      department: 'Security', 
      status: 'Present', 
      checkIn: '07:45',
      role: 'Security Officer',
      contact: '077-4567890'
    },
    { 
      id: 5, 
      name: 'Priyanka Wickramasinghe', 
      department: 'Administration', 
      status: 'Present', 
      checkIn: '08:00',
      role: 'Admin Assistant',
      contact: '077-5678901'
    }
  ]);

  const [searchTerm, setSearchTerm] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newEmployee, setNewEmployee] = useState({
    name: '',
    department: '',
    role: '',
    contact: ''
  });

  const filteredEmployees = employees.filter(emp => 
    emp.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    emp.department.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleAddEmployee = () => {
    const employee = {
      id: employees.length + 1,
      ...newEmployee,
      status: 'Present',
      checkIn: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })
    };
    
    setEmployees([...employees, employee]);
    setNewEmployee({ name: '', department: '', role: '', contact: '' });
    setDialogOpen(false);
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'Present': return 'success';
      case 'Absent': return 'error';
      case 'Late': return 'warning';
      default: return 'default';
    }
  };

  const presentCount = employees.filter(emp => emp.status === 'Present').length;
  const absentCount = employees.filter(emp => emp.status === 'Absent').length;

  return (
    <Box sx={{ p: 3 }}>
      <motion.div
        initial={{ y: -20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6 }}
      >
        <Typography variant="h4" gutterBottom sx={{ fontWeight: 'bold', color: '#2E7D32' }}>
          👥 Employee Management System
        </Typography>
        <Typography variant="subtitle1" color="textSecondary" sx={{ mb: 3 }}>
          Monitor and manage factory workforce
        </Typography>
      </motion.div>

      {/* Summary Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} md={4}>
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.1 }}
          >
            <Card elevation={4} sx={{ background: 'linear-gradient(135deg, #4CAF50, #45a049)' }}>
              <CardContent>
                <Box display="flex" alignItems="center" justifyContent="space-between">
                  <Box>
                    <Typography color="white" variant="h6" gutterBottom>
                      Present Today
                    </Typography>
                    <Typography color="white" variant="h3" fontWeight="bold">
                      {presentCount}
                    </Typography>
                  </Box>
                  <Avatar sx={{ bgcolor: 'rgba(255,255,255,0.3)', width: 56, height: 56 }}>
                    <Person fontSize="large" />
                  </Avatar>
                </Box>
              </CardContent>
            </Card>
          </motion.div>
        </Grid>

        <Grid item xs={12} md={4}>
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <Card elevation={4} sx={{ background: 'linear-gradient(135deg, #f44336, #d32f2f)' }}>
              <CardContent>
                <Box display="flex" alignItems="center" justifyContent="space-between">
                  <Box>
                    <Typography color="white" variant="h6" gutterBottom>
                      Absent Today
                    </Typography>
                    <Typography color="white" variant="h3" fontWeight="bold">
                      {absentCount}
                    </Typography>
                  </Box>
                  <Avatar sx={{ bgcolor: 'rgba(255,255,255,0.3)', width: 56, height: 56 }}>
                    <Person fontSize="large" />
                  </Avatar>
                </Box>
              </CardContent>
            </Card>
          </motion.div>
        </Grid>

        <Grid item xs={12} md={4}>
          <motion.div
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <Card elevation={4} sx={{ background: 'linear-gradient(135deg, #2196F3, #1976D2)' }}>
              <CardContent>
                <Box display="flex" alignItems="center" justifyContent="space-between">
                  <Box>
                    <Typography color="white" variant="h6" gutterBottom>
                      Total Employees
                    </Typography>
                    <Typography color="white" variant="h3" fontWeight="bold">
                      {employees.length}
                    </Typography>
                  </Box>
                  <Avatar sx={{ bgcolor: 'rgba(255,255,255,0.3)', width: 56, height: 56 }}>
                    <Person fontSize="large" />
                  </Avatar>
                </Box>
              </CardContent>
            </Card>
          </motion.div>
        </Grid>
      </Grid>

      {/* Search Bar */}
      <Card elevation={3} sx={{ mb: 3 }}>
        <CardContent>
          <TextField
            fullWidth
            variant="outlined"
            placeholder="Search employees by name or department..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: <Search sx={{ mr: 1, color: 'text.secondary' }} />
            }}
          />
        </CardContent>
      </Card>

      {/* Employee Table */}
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.4 }}
      >
        <Card elevation={5}>
          <CardContent>
            <Typography variant="h6" gutterBottom sx={{ fontWeight: 'bold' }}>
              Employee Directory
            </Typography>
            
            <TableContainer component={Paper} elevation={0}>
              <Table>
                <TableHead>
                  <TableRow sx={{ bgcolor: '#f5f5f5' }}>
                    <TableCell><strong>Employee Name</strong></TableCell>
                    <TableCell><strong>Department</strong></TableCell>
                    <TableCell><strong>Role</strong></TableCell>
                    <TableCell><strong>Status</strong></TableCell>
                    <TableCell><strong>Check-in Time</strong></TableCell>
                    <TableCell><strong>Contact</strong></TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {filteredEmployees.map((employee, index) => (
                    <motion.tr
                      key={employee.id}
                      component={TableRow}
                      initial={{ x: -20, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      transition={{ delay: index * 0.1 }}
                      sx={{ 
                        '&:hover': { bgcolor: '#f8f9fa' },
                        '&:nth-of-type(odd)': { bgcolor: '#fafafa' }
                      }}
                    >
                      <TableCell>
                        <Box display="flex" alignItems="center">
                          <Avatar sx={{ mr: 2, bgcolor: '#2E7D32' }}>
                            {employee.name.charAt(0)}
                          </Avatar>
                          {employee.name}
                        </Box>
                      </TableCell>
                      <TableCell>{employee.department}</TableCell>
                      <TableCell>{employee.role}</TableCell>
                      <TableCell>
                        <Chip 
                          label={employee.status} 
                          color={getStatusColor(employee.status)}
                          size="small"
                        />
                      </TableCell>
                      <TableCell>{employee.checkIn}</TableCell>
                      <TableCell>{employee.contact}</TableCell>
                    </motion.tr>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </CardContent>
        </Card>
      </motion.div>

      {/* Add Employee FAB */}
      <Fab
        color="primary"
        sx={{ position: 'fixed', bottom: 16, right: 16 }}
        onClick={() => setDialogOpen(true)}
      >
        <Add />
      </Fab>

      {/* Add Employee Dialog */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <DialogTitle>Add New Employee</DialogTitle>
        <DialogContent>
          <TextField
            fullWidth
            label="Full Name"
            margin="normal"
            value={newEmployee.name}
            onChange={(e) => setNewEmployee({...newEmployee, name: e.target.value})}
          />
          <TextField
            fullWidth
            label="Department"
            margin="normal"
            value={newEmployee.department}
            onChange={(e) => setNewEmployee({...newEmployee, department: e.target.value})}
          />
          <TextField
            fullWidth
            label="Role"
            margin="normal"
            value={newEmployee.role}
            onChange={(e) => setNewEmployee({...newEmployee, role: e.target.value})}
          />
          <TextField
            fullWidth
            label="Contact Number"
            margin="normal"
            value={newEmployee.contact}
            onChange={(e) => setNewEmployee({...newEmployee, contact: e.target.value})}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleAddEmployee} variant="contained">Add Employee</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default EmployeeManagement;
