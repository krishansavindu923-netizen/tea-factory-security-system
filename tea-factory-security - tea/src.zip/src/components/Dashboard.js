import React, { useState, useEffect } from 'react';
import { Grid, Card, CardContent, Typography, Box, Alert, LinearProgress, Chip } from '@mui/material';
import { motion } from 'framer-motion';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer, LineChart, Line } from 'recharts';

const Dashboard = () => {
  const [liveData, setLiveData] = useState({
    temperature: 24.5,
    humidity: 65,
    workers: 45,
    alerts: 0,
    systemStatus: 'OPERATIONAL'
  });

  const [activityLog, setActivityLog] = useState([
    { id: 1, time: '09:15', event: '✅ Employee Check-in: Kasun Silva', status: 'success' },
    { id: 2, time: '09:12', event: '📹 Camera Online: Zone A', status: 'info' },
    { id: 3, time: '09:10', event: '🚪 Access Granted: Main Entrance', status: 'success' },
    { id: 4, time: '09:08', event: '🔍 Motion Detected: Packaging Area', status: 'warning' },
    { id: 5, time: '09:05', event: '🛡️ Security Scan Complete', status: 'success' }
  ]);

  // Simulate real-time data updates
  useEffect(() => {
    const interval = setInterval(() => {
      setLiveData(prev => ({
        ...prev,
        temperature: 24 + Math.random() * 6,
        humidity: 60 + Math.random() * 20,
        workers: 40 + Math.floor(Math.random() * 15)
      }));

      // Add new activity occasionally
      if (Math.random() > 0.7) {
        const newActivity = {
          id: Date.now(),
          time: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
          event: '🔄 System Update: ' + ['Temperature sensor calibrated', 'Camera feed refreshed', 'Access log updated'][Math.floor(Math.random() * 3)],
          status: 'info'
        };
        
        setActivityLog(prev => [newActivity, ...prev.slice(0, 4)]);
      }
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  const securityData = [
    { name: 'Security', value: 95, color: '#4CAF50' },
    { name: 'Fire Safety', value: 100, color: '#2196F3' },
    { name: 'Access Control', value: 88, color: '#FF9800' },
    { name: 'Surveillance', value: 92, color: '#9C27B0' }
  ];

  const temperatureData = [
    { time: '09:00', temp: 24.2 },
    { time: '09:05', temp: 24.8 },
    { time: '09:10', temp: 25.1 },
    { time: '09:15', temp: liveData.temperature },
  ];

  const StatusCard = ({ title, value, unit, color, icon }) => (
    <motion.div
      initial={{ y: 50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6 }}
      whileHover={{ scale: 1.02 }}
    >
      <Card elevation={8} sx={{ 
        background: `linear-gradient(135deg, ${color}, ${color}dd)`,
        height: '100%',
        position: 'relative',
        overflow: 'hidden'
      }}>
        <CardContent sx={{ position: 'relative', zIndex: 2 }}>
          <Box display="flex" justifyContent="space-between" alignItems="center">
            <Box>
              <Typography variant="h6" color="white" gutterBottom sx={{ fontWeight: 500 }}>
                {title}
              </Typography>
              <Typography variant="h3" color="white" sx={{ fontWeight: 'bold', mb: 1 }}>
                {value}{unit}
              </Typography>
              <LinearProgress 
                variant="determinate" 
                value={85} 
                sx={{ 
                  bgcolor: 'rgba(255,255,255,0.3)', 
                  '& .MuiLinearProgress-bar': { bgcolor: 'rgba(255,255,255,0.8)' },
                  height: 6,
                  borderRadius: 3
                }} 
              />
            </Box>
            <Typography variant="h2" sx={{ opacity: 0.3, color: 'white' }}>
              {icon}
            </Typography>
          </Box>
        </CardContent>
        
        {/* Animated background effect */}
        <Box sx={{
          position: 'absolute',
          top: -50,
          right: -50,
          width: 100,
          height: 100,
          bgcolor: 'rgba(255,255,255,0.1)',
          borderRadius: '50%',
          zIndex: 1
        }} />
      </Card>
    </motion.div>
  );

  return (
    <Box sx={{ flexGrow: 1, p: 3, bgcolor: '#f8fafc', minHeight: '100vh' }}>
      {/* Header */}
      <motion.div 
        initial={{ x: -100, opacity: 0 }} 
        animate={{ x: 0, opacity: 1 }}
        transition={{ duration: 0.8 }}
      >
        <Typography variant="h3" gutterBottom color="primary" sx={{ fontWeight: 'bold', mb: 1 }}>
          🏭 Security Command Center
        </Typography>
        <Typography variant="subtitle1" color="textSecondary" sx={{ mb: 3 }}>
          Real-time monitoring and control system for Craig Tea Factory
        </Typography>
        
        <Alert 
          severity="success" 
          sx={{ 
            mb: 4, 
            fontSize: '1.1rem',
            '& .MuiAlert-icon': { fontSize: '1.5rem' }
          }}
        >
          🟢 All Systems Operational - Factory Secure & Running Smoothly
        </Alert>
      </motion.div>

      {/* Live Status Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <StatusCard 
            title="🌡️ Temperature"
            value={liveData.temperature.toFixed(1)}
            unit="°C"
            color="#FF5722"
            icon="🌡️"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatusCard 
            title="💧 Humidity"
            value={liveData.humidity.toFixed(0)}
            unit="%"
            color="#2196F3"
            icon="💧"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatusCard 
            title="👥 Workers"
            value={liveData.workers}
            unit=" Active"
            color="#4CAF50"
            icon="👥"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatusCard 
            title="🚨 Alerts"
            value={liveData.alerts}
            unit=" Active"
            color="#9C27B0"
            icon="🚨"
          />
        </Grid>
      </Grid>

      {/* Charts & Activity */}
      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Card elevation={6} sx={{ mb: 3 }}>
            <CardContent>
              <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: '#2E7D32' }}>
                📊 Security System Performance
              </Typography>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={securityData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                  <XAxis dataKey="name" stroke="#666" />
                  <YAxis stroke="#666" />
                  <Bar dataKey="value" fill="#2E7D32" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card elevation={6}>
            <CardContent>
              <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: '#2E7D32' }}>
                📈 Temperature Monitoring
              </Typography>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={temperatureData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                  <XAxis dataKey="time" stroke="#666" />
                  <YAxis stroke="#666" />
                  <Line type="monotone" dataKey="temp" stroke="#FF5722" strokeWidth={3} dot={{ fill: '#FF5722', r: 6 }} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </Grid>

        <Grid item xs={12} md={4}>
          <Card elevation={6} sx={{ height: 'fit-content' }}>
            <CardContent>
              <Typography variant="h5" gutterBottom sx={{ fontWeight: 'bold', color: '#2E7D32' }}>
                🔴 Live Activity Feed
              </Typography>
              <Box sx={{ maxHeight: 400, overflowY: 'auto' }}>
                {activityLog.map((activity, index) => (
                  <motion.div
                    key={activity.id}
                    initial={{ x: 50, opacity: 0 }}
                    animate={{ x: 0, opacity: 1 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Box sx={{ 
                      mb: 2, 
                      p: 2, 
                      bgcolor: '#f8f9fa', 
                      borderRadius: 2, 
                      borderLeft: `4px solid ${
                        activity.status === 'success' ? '#4CAF50' : 
                        activity.status === 'warning' ? '#FF9800' : '#2196F3'
                      }`,
                      transition: 'transform 0.2s',
                      '&:hover': { transform: 'translateX(5px)' }
                    }}>
                      <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
                        <Typography variant="body2" color="textSecondary" sx={{ fontWeight: 'bold' }}>
                          {activity.time}
                        </Typography>
                        <Chip 
                          label={activity.status} 
                          size="small" 
                          color={activity.status === 'success' ? 'success' : activity.status === 'warning' ? 'warning' : 'info'}
                        />
                      </Box>
                      <Typography variant="body1">{activity.event}</Typography>
                    </Box>
                  </motion.div>
                ))}
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard;
